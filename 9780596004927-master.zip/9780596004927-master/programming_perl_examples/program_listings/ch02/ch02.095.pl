while (<*.c>) {
    chmod 0644, $_;
}
