(@stuff,@nonsense,funkshun())
