while (glob "*.c") {
    chmod 0644, $_;
}
