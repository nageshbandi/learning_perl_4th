my $temp = join( $", @ARGV );
print $temp;

print "@ARGV";
