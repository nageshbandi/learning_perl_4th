$fh = *STDOUT{IO};
