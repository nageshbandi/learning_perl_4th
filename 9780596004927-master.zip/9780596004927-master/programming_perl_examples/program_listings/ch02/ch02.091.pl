open(my $fh, '<', "data.txt");
$line = <$fh>;
