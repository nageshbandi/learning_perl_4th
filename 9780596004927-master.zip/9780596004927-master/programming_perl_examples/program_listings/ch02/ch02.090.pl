$fh = \*STDIN;
$line = <$fh>;
