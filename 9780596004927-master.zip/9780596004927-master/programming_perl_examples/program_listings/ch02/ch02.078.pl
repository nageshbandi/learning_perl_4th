$info = `perldoc $module`;
