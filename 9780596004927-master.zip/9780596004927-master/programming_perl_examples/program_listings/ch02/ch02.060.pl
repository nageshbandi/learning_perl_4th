@whatever = ();
$#whatever = -1;
