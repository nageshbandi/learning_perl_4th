while (my $line = <STDIN>) { print $line } # now private
