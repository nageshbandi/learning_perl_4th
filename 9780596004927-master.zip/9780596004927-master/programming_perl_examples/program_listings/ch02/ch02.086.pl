while (<>) {
    ...                     # code for each line
}
