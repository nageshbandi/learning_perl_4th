@stuff = ("one", "two", "three");
$stuff = @stuff;
