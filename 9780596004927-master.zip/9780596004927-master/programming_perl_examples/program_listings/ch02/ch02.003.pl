=pod

my $dog = 'Spot';
my $cat = 'Buster';

=cut
