my $Price = '$100';                 # not interpolated
print "The price is $Price.\n";     # interpolated
