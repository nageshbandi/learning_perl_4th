@stuff = ("one", "two", "three");
