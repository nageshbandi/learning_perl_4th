local *Here::blue = \$There::green;
