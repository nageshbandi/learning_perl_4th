"Camel Lot";
