"${verb}able"
$days{Feb}
