$fh = *STDOUT;
