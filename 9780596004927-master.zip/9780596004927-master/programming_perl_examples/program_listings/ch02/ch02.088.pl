# default to README file if no args given
@ARGV = ("README") unless @ARGV;
