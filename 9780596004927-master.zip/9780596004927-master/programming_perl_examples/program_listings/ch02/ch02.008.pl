$Santa::Helper::Reindeer::Rudolph::nose
