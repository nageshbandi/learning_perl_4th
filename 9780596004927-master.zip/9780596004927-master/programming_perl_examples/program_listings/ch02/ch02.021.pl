tr (a-f)
   [A-F];
