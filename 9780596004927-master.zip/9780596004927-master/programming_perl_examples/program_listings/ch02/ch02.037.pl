($x,$y,$z) = funkshun();  # list context
($x)       = funkshun();  # list context
