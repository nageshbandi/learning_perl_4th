while (local $_ = <STDIN>) { print }   # temporary value to global $_
