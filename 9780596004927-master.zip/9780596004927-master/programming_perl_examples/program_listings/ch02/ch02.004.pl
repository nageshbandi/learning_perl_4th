# start of a multiline comment
# my $dog = 'Spot';
# my $cat = 'Buster';
