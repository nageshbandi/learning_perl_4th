my @days = (Mon,Tue,Wed,Thu,Fri);
print STDOUT hello, " ", world, "\n";
