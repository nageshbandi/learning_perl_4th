while (my $_ = <STDIN>) { print }      # a new, lexical $_
