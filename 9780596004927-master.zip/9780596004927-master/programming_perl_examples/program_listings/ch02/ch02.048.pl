@releases = (
    "alpha",
    "beta",
    "gamma",
);
