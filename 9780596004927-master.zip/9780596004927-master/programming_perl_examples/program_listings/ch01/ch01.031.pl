say "Adam's wife is $wife{'Adam'}.";
