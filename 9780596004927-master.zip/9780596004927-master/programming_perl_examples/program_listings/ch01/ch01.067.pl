while (@ARGV) {
    process(shift @ARGV);
}
