chomp($number = <STDIN>);    # input a number, then remove its newline
