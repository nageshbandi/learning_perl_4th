sort @dudes, @chicks, other();
