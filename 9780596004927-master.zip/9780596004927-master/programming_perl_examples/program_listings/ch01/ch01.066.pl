while (my $line = <GRADES>) {
