package Dog;
our $fido = &fetch();
