s/(?<alpha>\S+)\s+(?<beta>\S+)/$+{beta} $+{alpha}/
