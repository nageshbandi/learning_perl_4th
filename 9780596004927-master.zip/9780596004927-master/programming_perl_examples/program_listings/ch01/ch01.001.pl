print "Howdy, world!\n";
