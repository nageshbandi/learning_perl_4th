my %wife;
$wife{"Adam"} = "Eve";
