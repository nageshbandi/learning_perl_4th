$_ = "fred xxxxxxx barney";
s/x*//;
