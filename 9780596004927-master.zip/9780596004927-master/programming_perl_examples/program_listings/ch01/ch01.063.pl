unless ($destination eq $home) {
    say "I'm not going home.";
}
