$wife{"Jacob"} = ["Leah", "Rachel", "Bilhah", "Zilpah"];        # ok
