larry:JYHtPh0./NJTU:100:10:Larry Wall:/home/larry:/bin/bash
