for (;;) {
    say "Take out the trash!";
    sleep(5);
}
