my ($hour, $min, $sec, $ampm) = /(\d+):(\d+):(\d+) *(\w+)/;
