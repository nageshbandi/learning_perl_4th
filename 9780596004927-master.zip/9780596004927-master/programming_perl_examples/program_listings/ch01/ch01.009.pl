($alpha,$omega) = ($omega,$alpha);
