my $e = exp(1);   # 2.718281828459 or thereabouts
