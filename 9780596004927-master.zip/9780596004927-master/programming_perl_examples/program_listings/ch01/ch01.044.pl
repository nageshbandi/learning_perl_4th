$number = <STDIN>;           # input a number
chomp($number);              # remove trailing newline
