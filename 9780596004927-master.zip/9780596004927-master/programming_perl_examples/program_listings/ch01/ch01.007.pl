my @home = ("couch", "chair", "table", "stove");
