if ($pathname =~ /\.(.)\z/s) {
    say "Ends in $1";
}
