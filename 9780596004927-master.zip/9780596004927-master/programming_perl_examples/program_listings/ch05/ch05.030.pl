use re "/u";        # Unicode mode
use re "/d";        # dual ASCII-Unicode mode
use re "/l";        # 8-bit locale mode
use re "/a";        # ASCII mode, plus Unicode casefolding
use re "/aa";       # ASCIIer mode, without Unicode casefolding
