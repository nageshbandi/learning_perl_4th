match( $string, $pattern );
subst( $string, $pattern, $replacement );
