($lotr = $hobbit) =~ s/Bilbo/Frodo/g;
