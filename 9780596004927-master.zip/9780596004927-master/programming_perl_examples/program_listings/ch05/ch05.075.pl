"exasperate" =~ /e(.*)e/    #  $1 now "xasperat"
