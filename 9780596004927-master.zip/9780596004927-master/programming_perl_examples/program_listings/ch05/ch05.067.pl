"SS" =~ /^[\xDF]$/iu
