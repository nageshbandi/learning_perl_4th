"foofoobar" =~ /^(\1bar|(foo))+/            # circumref
