/Frodo|Pippin|Merry|Sam/
