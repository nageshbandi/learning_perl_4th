$string = join(" ", split " ", $string);
