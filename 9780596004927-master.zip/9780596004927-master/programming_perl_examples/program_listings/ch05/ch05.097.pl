"foofoobar" =~ /^((\3bar)|(foo))+$/         # forwref
