@newhues = map { s/blue/red/r } @oldhues;
