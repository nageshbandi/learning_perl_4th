("a" x 20 . "b") =~ /(a*a*a*a*a*a*a*a*a*a*a*a*)*[^Bb]$/
