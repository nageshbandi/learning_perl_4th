$lotr = $hobbit;
$lotr =~ s/Bilbo/Frodo/g;
