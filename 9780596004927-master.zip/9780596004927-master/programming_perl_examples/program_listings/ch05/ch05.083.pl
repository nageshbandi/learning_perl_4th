/\bis\b/   # matches "what it is" and "that is it"
/\Bis\B/   # matches "thistle" and "artist"
/\bis\B/   # matches "istanbul" and "so—isn't that butter?"
/\Bis\b/   # matches "confutatis" and "metropolis near you"
