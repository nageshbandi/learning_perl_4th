$string = "password=xyzzy verbose=9 score=0";
