sub check_warehouse {
    for my $widget (our @Current_Inventory) {
        say "I have a $widget in stock today.";
    }
}
