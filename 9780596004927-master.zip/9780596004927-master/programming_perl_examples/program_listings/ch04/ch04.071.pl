print ...;                                  # WRONG
open(my $fh, ">", "/dev/passwd") or ...;    # WRONG
if ($condition && ... ) { say "Howdy" };    # WRONG
