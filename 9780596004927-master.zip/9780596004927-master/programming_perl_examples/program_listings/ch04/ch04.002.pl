$trash->take("out") if $you_love_me;
shutup() unless $you_want_me_to_leave;
