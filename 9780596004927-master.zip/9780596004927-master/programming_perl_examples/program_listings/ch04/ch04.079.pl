my ($foo) = <STDIN>;
my @array = <STDIN>;
