no strict "vars";
