{
  local $var = $newvalue;
  some_func();
  ...
}
