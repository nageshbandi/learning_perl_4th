do {
    $line = <STDIN>;
    ...
} until $line eq ".\n";
