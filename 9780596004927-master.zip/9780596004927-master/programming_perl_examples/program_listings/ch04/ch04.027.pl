when (['foo', 'bar']) { ... }
