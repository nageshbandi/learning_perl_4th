use warnings;
use strict;
use integer;
use bytes;
use constant pi => ( 4 * atan2(1,1) );
