use feature "switch";   # just get the switch feature
