LABEL:
  for (my $i = 1; $i <= 10; $i++) {
      ...
  }
