sub myname;
$me = myname $0   or die "can't get myname";
