sub myname ($);
$me = myname $0   || die "can't get myname";
