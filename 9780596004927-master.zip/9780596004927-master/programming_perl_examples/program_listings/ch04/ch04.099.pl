use v5.14;            # Turn on strict implicitly.
use strict "vars";    # Turn on strict explicitly.
