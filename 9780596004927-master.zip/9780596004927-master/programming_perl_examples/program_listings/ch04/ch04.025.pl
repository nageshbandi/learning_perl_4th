when (/^baz/ || [qw(foo bar)]) { ... }
