a and b are deep copies of each other
