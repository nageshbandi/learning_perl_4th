next unless -f $file && -T $file;
