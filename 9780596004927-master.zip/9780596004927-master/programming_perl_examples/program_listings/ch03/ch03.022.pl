$hash{perls}  = "";
$hash{before} = "";
$hash{swine}  = "";
