my $yogi = Bear->new("Yogi");  # a class method call
$yogi->swipe('picnic basket'); # an object method call
