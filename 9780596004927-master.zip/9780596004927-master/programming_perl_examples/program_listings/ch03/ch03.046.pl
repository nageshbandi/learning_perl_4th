 %hash ~~ $object
    42 ~~ $object
"fred" ~~ $object
