my %hash;
my @keys = qw(perls before swine);
@hash{@keys} = ("") x @keys;
