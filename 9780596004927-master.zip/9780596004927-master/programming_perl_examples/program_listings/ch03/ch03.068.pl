my @bigcombos = ("aaaaaaa" .. "zzzzzzz");
