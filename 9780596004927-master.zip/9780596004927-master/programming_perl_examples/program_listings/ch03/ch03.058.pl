$value = $hash{$key} // "DEFAULT";
