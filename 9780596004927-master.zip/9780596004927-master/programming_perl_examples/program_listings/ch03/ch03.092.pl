my $new = ($old =~ s/foo/bar/gr);
my $new =  $old =~ s/foo/bar/gr;
