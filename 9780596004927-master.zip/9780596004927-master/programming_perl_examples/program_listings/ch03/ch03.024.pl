my $fullname = "$firstname $lastname";
