$string !~ /pattern/
!(  $string =~ /pattern/ )
not $string =~ /pattern/
