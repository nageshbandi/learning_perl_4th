($tmp = $global) += $constant;
