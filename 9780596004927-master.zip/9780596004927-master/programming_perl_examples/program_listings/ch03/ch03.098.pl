unlink "alpha", "beta", "gamma"
        or gripe(), next LINE;
