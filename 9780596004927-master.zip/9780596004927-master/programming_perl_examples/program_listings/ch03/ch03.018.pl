$a % $b == $a - ( POSIX::floor($a / $b) * $b )
