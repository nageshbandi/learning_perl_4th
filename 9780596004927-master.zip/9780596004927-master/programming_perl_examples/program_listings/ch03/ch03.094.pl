while (my ($key, $value) = each %gloss) { ... }

next unless my ($dev, $ino, $mode) = stat $file;
