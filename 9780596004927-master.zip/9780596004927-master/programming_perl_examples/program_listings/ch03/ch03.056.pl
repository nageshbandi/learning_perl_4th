open(FILE, "<", "somefile") || die "Can't open somefile: $!\n";
