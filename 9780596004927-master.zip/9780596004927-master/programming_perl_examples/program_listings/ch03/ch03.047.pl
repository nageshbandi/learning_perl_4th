$object ~~ $number          ref($object) == $number
$object ~~ $string          ref($object) eq $string
