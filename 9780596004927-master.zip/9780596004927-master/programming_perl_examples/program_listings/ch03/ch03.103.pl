$ref_to_var = \$var;
