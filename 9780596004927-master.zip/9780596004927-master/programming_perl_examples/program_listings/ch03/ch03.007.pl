my @ary = (1, 3, sort 4, 2);
print @ary;         # prints 1324
